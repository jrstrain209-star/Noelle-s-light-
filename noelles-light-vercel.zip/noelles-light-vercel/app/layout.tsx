import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Noelle’s Light",
  description: "A safe place to say, “I’m not okay.”",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
