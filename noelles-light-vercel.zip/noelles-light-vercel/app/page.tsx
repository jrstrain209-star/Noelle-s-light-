\
import { Heart, MapPin, MessageCircleHeart, Users, HandHeart, ShieldAlert } from "lucide-react";

const cards = [
  {
    title: "Find Help",
    text: "Access crisis lines, grief resources, therapists, counselors, and support services.",
    icon: MapPin,
  },
  {
    title: "Support Groups",
    text: "Join online support communities or find local in-person groups near you.",
    icon: Users,
  },
  {
    title: "Share Your Heart",
    text: "Post anonymously and connect with others safely, gently, and respectfully.",
    icon: MessageCircleHeart,
  },
  {
    title: "Help Others",
    text: "Offer encouragement and support to people who need to feel less alone.",
    icon: HandHeart,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-900 text-white overflow-hidden relative">
      <div className="absolute inset-0 star-field opacity-70 pointer-events-none" />

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-purple-500/15 blur-3xl" />
        <div className="absolute top-1/3 -left-32 h-[420px] w-[420px] rounded-full bg-indigo-400/10 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-[420px] w-[420px] rounded-full bg-blue-400/10 blur-3xl" />
      </div>

      <a
        href="#immediate-help"
        className="safe-focus fixed bottom-5 right-5 z-50 rounded-full bg-red-500 px-5 py-3 text-sm font-bold text-white shadow-2xl transition hover:bg-red-400 sm:text-base"
      >
        Get Help Now
      </a>

      <nav className="relative z-10 border-b border-white/10 bg-slate-950/20 px-5 py-5 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
          <a href="#" className="safe-focus rounded-xl">
            <p className="text-xl font-bold tracking-wide sm:text-2xl">Noelle’s Light</p>
            <p className="text-xs text-indigo-200 sm:text-sm">A safe place to say, “I’m not okay.”</p>
          </a>

          <div className="hidden items-center gap-6 text-sm text-slate-200 md:flex">
            <a className="safe-focus rounded-lg hover:text-white" href="#story">Noelle’s Story</a>
            <a className="safe-focus rounded-lg hover:text-white" href="#help">Find Help</a>
            <a className="safe-focus rounded-lg hover:text-white" href="#groups">Support Groups</a>
            <a className="safe-focus rounded-lg hover:text-white" href="#share">Share</a>
          </div>
        </div>
      </nav>

      <section className="relative z-10 mx-auto max-w-5xl px-5 pb-16 pt-20 text-center sm:pt-28">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-indigo-300/20 bg-white/5 px-4 py-2 text-sm text-indigo-100 backdrop-blur-sm">
          <Heart className="h-4 w-4" />
          In loving memory of Noelle
        </div>

        <h1 className="mb-6 text-5xl font-bold leading-tight tracking-tight sm:text-7xl">
          Noelle’s Light
        </h1>

        <p className="mx-auto mb-10 max-w-3xl text-lg leading-relaxed text-indigo-100 sm:text-2xl">
          A calm and supportive space where people can share their feelings,
          find support, help others, and remember they are not alone.
        </p>

        <div className="mx-auto flex max-w-xl flex-col items-center justify-center gap-4 sm:flex-row">
          <a
            href="#share"
            className="safe-focus w-full rounded-2xl bg-indigo-500 px-8 py-4 text-center text-lg font-semibold shadow-xl transition hover:bg-indigo-400"
          >
            Share Your Heart
          </a>

          <a
            href="#help"
            className="safe-focus w-full rounded-2xl border border-white/10 bg-white/10 px-8 py-4 text-center text-lg font-semibold backdrop-blur-sm transition hover:bg-white/20"
          >
            Find Support Near Me
          </a>
        </div>
      </section>

      <section id="story" className="relative z-10 mx-auto max-w-5xl px-5 py-8">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-7 shadow-glow backdrop-blur-md sm:p-12">
          <h2 className="mb-6 text-3xl font-semibold">You are not alone.</h2>

          <div className="space-y-4 text-base leading-relaxed text-slate-200 sm:text-lg">
            <p>
              Noelle’s Light was created for anyone who feels overwhelmed,
              unheard, isolated, grieving, anxious, or emotionally exhausted.
            </p>

            <p>
              This is a place where people can speak honestly without fear of judgment.
            </p>

            <p>
              Whether you are struggling silently, supporting someone you love,
              grieving a loss, or simply trying to make it through another day —
              you belong here.
            </p>
          </div>
        </div>
      </section>

      <section id="help" className="relative z-10 mx-auto grid max-w-6xl grid-cols-1 gap-5 px-5 py-16 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => {
          const Icon = card.icon;

          return (
            <article
              key={card.title}
              className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition hover:bg-white/10"
            >
              <Icon className="mb-5 h-8 w-8 text-indigo-200" />
              <h3 className="mb-3 text-2xl font-semibold">{card.title}</h3>
              <p className="leading-relaxed text-slate-300">{card.text}</p>
            </article>
          );
        })}
      </section>

      <section id="share" className="relative z-10 mx-auto max-w-5xl px-5 py-8">
        <div className="rounded-3xl border border-white/10 bg-slate-950/30 p-7 backdrop-blur-md sm:p-10">
          <h2 className="mb-4 text-3xl font-semibold">Share Your Heart</h2>
          <p className="mb-6 max-w-3xl leading-relaxed text-slate-200">
            The first version of this space will use moderated anonymous posts so people
            can share safely without bullying, shaming, or judgment.
          </p>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-5 text-slate-300">
            Coming next: anonymous posting, moderated replies, support categories,
            local resources, and support group submissions.
          </div>
        </div>
      </section>

      <section id="groups" className="relative z-10 mx-auto max-w-5xl px-5 py-8">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-7 backdrop-blur-md sm:p-10">
          <h2 className="mb-4 text-3xl font-semibold">Support Groups</h2>
          <p className="leading-relaxed text-slate-200">
            This section will help people find online support groups, in-person local groups,
            grief support, teen support, parent support, and community-submitted resources.
          </p>
        </div>
      </section>

      <section id="immediate-help" className="relative z-10 px-5 pb-20 pt-8">
        <div className="mx-auto max-w-5xl rounded-3xl border border-red-400/20 bg-red-500/10 p-7 text-center backdrop-blur-sm sm:p-10">
          <div className="mb-4 flex justify-center">
            <ShieldAlert className="h-9 w-9 text-red-200" />
          </div>

          <h2 className="mb-4 text-2xl font-semibold sm:text-3xl">Need immediate support?</h2>

          <p className="mx-auto mb-6 max-w-3xl text-base leading-relaxed text-slate-200 sm:text-lg">
            Call or text <span className="font-bold text-white">988</span> if you are in emotional distress
            or having thoughts of self-harm. If you are in immediate danger, call emergency services.
          </p>

          <a
            href="tel:988"
            className="safe-focus inline-block rounded-2xl bg-red-500 px-8 py-4 text-lg font-semibold shadow-xl transition hover:bg-red-400"
          >
            Call 988
          </a>

          <p className="mx-auto mt-5 max-w-2xl text-sm leading-relaxed text-slate-300">
            Noelle’s Light is a peer support community. It is not a replacement for emergency help,
            therapy, medical care, or professional mental health support.
          </p>
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/10 px-5 py-10 text-center text-sm text-slate-400">
        <p className="mb-2 font-semibold text-slate-300">Noelle’s Light</p>
        <p>Built in memory of Noelle to help people feel heard, supported, and less alone.</p>
      </footer>
    </main>
  );
}
